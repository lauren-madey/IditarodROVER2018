Open the mazeSolution_1 INO file first
